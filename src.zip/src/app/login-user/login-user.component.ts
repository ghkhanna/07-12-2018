import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';
import { GlobalsService } from '../globals.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here"
  errorMessage:string
  
  

  constructor(private firstName:string,private lastName:string, private dob:string, private emailId:string, private gender:string,private password:string, private user:User, private router:Router,private userService : UserService,private global:GlobalsService) { }

  ngOnInit() {
  }

  onClick(emailId:string, password:string){
    this.userService.getUser(emailId).subscribe((data:User)=> this.user = {
      firstName: data['firstName'],
      lastName:data['lastName'],
      dob:data['dob'],
      emailId:data['emailId'],
      gender:data['gender'],
      password: data['password']
    }
    );

    if (this.user.password===password) {
      this.router.navigate(['/wall',emailId])
    } else {
      this.router.navigate(['/welcome'])
    }
  }
}