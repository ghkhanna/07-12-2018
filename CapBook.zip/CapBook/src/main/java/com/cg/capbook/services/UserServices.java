package com.cg.capbook.services;
import java.util.List;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface UserServices {
	
	User registerUser(User user) ;
	User getUserDetails(int userId) throws UserDetailsNotFoundException;
	User editUserDetails(User user);
	boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException;
	List<User> getAllUserDetails();
	User loginUser(String emailId, String password) throws IncorrectPasswordException, UserDetailsNotFoundException;
	boolean userExists(User user);
	User getUserId(String emailId);
	boolean cancelSentRequest(int userIdSender, int userIdrecieved) throws UserDetailsNotFoundException;
	boolean acceptFriendRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException;
	boolean sendFriendRequest(int userIdSender, int userIdreceiver)
			throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException;
	List<User> getAllUserFewDetails(String firstName) throws UserDetailsNotFoundException;
	boolean rejectRequest(int userIdSender, int userIdrecieved) throws UserDetailsNotFoundException;
}